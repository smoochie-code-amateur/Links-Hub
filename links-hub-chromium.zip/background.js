if (typeof chrome.sidePanel !== 'undefined') {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
}


chrome.action.onClicked.addListener((tab) => {
  if (typeof chrome.sidebarAction !== 'undefined') {
    chrome.sidebarAction.toggle();
  }
});