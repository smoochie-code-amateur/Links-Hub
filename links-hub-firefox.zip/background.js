
chrome.action.onClicked.addListener(() => {
  if (typeof chrome.sidebarAction !== 'undefined') {
    chrome.sidebarAction.toggle();
  }
});
