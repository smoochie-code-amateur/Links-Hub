const i18n = {
  uk: {
    editOn:      'Ред.',
    promptCat:   'Назва категорії:',
    promptName:  'Назва сайту:',
    promptUrl:   'URL:',
    promptPage:  'Назва сторінки:',
    addCat:      '+ Додати категорію',
    cats: {
      'Social':       'Соцмережі',
      'Work':         'Робота',
      'News':         'Новини',
      'Design':       'Дизайн',
      'Development':  'Розробка',
      'Entertainment':'Розваги',
      'Shopping':     'Покупки',
      'Other':        'Інше',
    }
  },
  en: {
    editOn:      'Edit',
    promptCat:   'Category Name:',
    promptName:  'Site Name:',
    promptUrl:   'URL:',
    promptPage:  'Page name:',
    addCat:      '+ Add Category',
    cats: {
      'Social':       'Social',
      'Work':         'Work',
      'News':         'News',
      'Design':       'Design',
      'Development':  'Development',
      'Entertainment':'Entertainment',
      'Shopping':     'Shopping',
      'Other':        'Other',
    }
  }
};

const DEFAULT_PAGES = [
  {
    id: 'page_default',
    name: 'Головна',
    categories: [
      { id: 'Social', links: [
        { name: 'Twitter / X', url: 'https://x.com' },
        { name: 'Instagram',   url: 'https://instagram.com' },
        { name: 'Facebook',    url: 'https://facebook.com' },
        { name: 'LinkedIn',    url: 'https://linkedin.com' },
      ]},
      { id: 'Design', links: [
        { name: 'Figma',    url: 'https://figma.com' },
        { name: 'Photopea', url: 'https://photopea.com' },
        { name: 'unDraw',   url: 'https://undraw.co' },
        { name: 'Iconify',  url: 'https://iconify.design' },
      ]},
      { id: 'Development', links: [
        { name: 'GitHub',         url: 'https://github.com' },
        { name: 'MDN Docs',       url: 'https://developer.mozilla.org' },
        { name: 'Stack Overflow', url: 'https://stackoverflow.com' },
        { name: 'CodePen',        url: 'https://codepen.io' },
      ]},
    ]
  }
];


let pages       = [];
let currentPage = '';
let isEditing   = false;
let currentLang = 'uk';
let customColors = {
  bg: '#ece9d8', surface: '#ffffff', header: '#000080',
  headerText: '#ffffff', text: '#000000', accent: '#000080', radius: 0,
};


const contentEl    = document.getElementById('content');
const themeSelect  = document.getElementById('themeSelect');
const langSelect   = document.getElementById('langSelect');
const chkEdit      = document.getElementById('chkEdit');
const toggleLabel  = document.getElementById('toggleLabel');
const btnCustomize = document.getElementById('btnCustomize');
const customPanel  = document.getElementById('customPanel');
const addCatWrap   = document.getElementById('addCatWrap');
const btnAddCat    = document.getElementById('btnAddCat');
const pageSelect   = document.getElementById('pageSelect');
const btnAddPage   = document.getElementById('btnAddPage');
const btnDeletePage= document.getElementById('btnDeletePage');
const btnRenamePage= document.getElementById('btnRenamePage');
const cpBg         = document.getElementById('cpBg');
const cpSurface    = document.getElementById('cpSurface');
const cpHeader     = document.getElementById('cpHeader');
const cpHeaderText = document.getElementById('cpHeaderText');
const cpText       = document.getElementById('cpText');
const cpAccent     = document.getElementById('cpAccent');
const cpRadius     = document.getElementById('cpRadius');
const cpRadiusVal  = document.getElementById('cpRadiusVal');
const btnSaveCust  = document.getElementById('btnSaveCustom');


chrome.storage.local.get(null, (res) => {
  
  if (res.linksData && !res.pages) {
    pages = [{ id: 'page_default', name: 'Головна', categories: res.linksData }];
  } else {
    pages = res.pages || DEFAULT_PAGES;
  }

  currentPage  = res.currentPage  || pages[0].id;
  currentLang  = res.lang         || 'uk';
  customColors = res.customColors || customColors;

  langSelect.value  = currentLang;
  themeSelect.value = res.theme || 'win98';

  applyTheme();
  renderPageSelect();
  render();
});


function applyTheme() {
  const t = themeSelect.value;
  document.documentElement.setAttribute('data-theme', t);
  if (t === 'custom') applyCustomColors();
  else clearCustomColors();
  chrome.storage.local.set({ theme: t });
}

function applyCustomColors() {
  const s = document.documentElement.style;
  s.setProperty('--bg-main',     customColors.bg);
  s.setProperty('--bg-surface',  customColors.surface);
  s.setProperty('--bg-header',   customColors.header);
  s.setProperty('--text-header', customColors.headerText);
  s.setProperty('--text-main',   customColors.text);
  s.setProperty('--accent',      customColors.accent);
  s.setProperty('--radius',      customColors.radius + 'px');
}

function clearCustomColors() {
  ['--bg-main','--bg-surface','--bg-header','--text-header','--text-main','--accent','--radius']
    .forEach(v => document.documentElement.style.removeProperty(v));
}


function getCurrentPage() {
  return pages.find(p => p.id === currentPage) || pages[0];
}

function renderPageSelect() {
  pageSelect.innerHTML = '';
  pages.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    if (p.id === currentPage) opt.selected = true;
    pageSelect.appendChild(opt);
  });
  
  btnDeletePage.disabled = pages.length <= 1;
}

pageSelect.addEventListener('change', () => {
  currentPage = pageSelect.value;
  chrome.storage.local.set({ currentPage });
  render();
});

btnAddPage.addEventListener('click', () => {
  const name = prompt(i18n[currentLang].promptPage, '');
  if (!name) return;
  const id = 'page_' + Date.now();
  pages.push({ id, name, categories: [] });
  currentPage = id;
  save();
  renderPageSelect();
  render();
});

btnDeletePage.addEventListener('click', () => {
  if (pages.length <= 1) return;
  const page = getCurrentPage();
  if (!confirm(`Видалити сторінку "${page.name}"?`)) return;
  pages = pages.filter(p => p.id !== currentPage);
  currentPage = pages[0].id;
  save();
  renderPageSelect();
  render();
});

btnRenamePage.addEventListener('click', () => {
  const page = getCurrentPage();
  const name = prompt(i18n[currentLang].promptPage, page.name);
  if (!name) return;
  page.name = name;
  save();
  renderPageSelect();
});


function render() {
  contentEl.innerHTML = '';
  const t    = i18n[currentLang];
  const page = getCurrentPage();

  page.categories.forEach((cat, catIdx) => {
    const catName = t.cats[cat.id] || cat.id;
    const div = document.createElement('div');
    div.className = 'category';

    const header = document.createElement('div');
    header.className = 'cat-header';
    const span = document.createElement('span');
    span.textContent = catName;
    header.appendChild(span);

    if (isEditing) {
      const actions = document.createElement('div');
      actions.className = 'header-actions';

      const addBtn = document.createElement('button');
      addBtn.textContent = '+';
      addBtn.className   = 'btn-header';
      addBtn.onclick = e => { e.stopPropagation(); addLink(catIdx); };

      const delBtn = document.createElement('button');
      delBtn.textContent = '×';
      delBtn.className   = 'btn-header';
      delBtn.onclick = e => { e.stopPropagation(); deleteCategory(catIdx); };

      actions.append(addBtn, delBtn);
      header.appendChild(actions);
    }
    div.appendChild(header);

    const grid = document.createElement('div');
    grid.className = 'links-grid';

    cat.links.forEach((l, linkIdx) => {
      const a = document.createElement('a');
      a.className = 'link-item';
      a.href      = l.url;
      a.target    = '_blank';
      a.rel       = 'noopener';

      let hostname = '';
      try { hostname = new URL(l.url).hostname; } catch {}

      const img = document.createElement('img');
      img.src     = `https://www.google.com/s2/favicons?domain=${hostname}&sz=16`;
      img.width   = 16;
      img.height  = 16;
      img.onerror = () => { img.style.display = 'none'; };

      const span = document.createElement('span');
      span.textContent = l.name;

      a.append(img, span);

      if (isEditing) {
        const btnDel = document.createElement('button');
        btnDel.className   = 'btn-del';
        btnDel.textContent = '×';
        btnDel.onclick = e => { e.preventDefault(); deleteLink(catIdx, linkIdx); };
        a.appendChild(btnDel);
      }

      grid.appendChild(a);
    });

    div.appendChild(grid);
    contentEl.appendChild(div);
  });

  addCatWrap.classList.toggle('hidden', !isEditing);
  btnAddCat.textContent   = t.addCat;
  toggleLabel.textContent = t.editOn;
}


function addLink(catIdx) {
  const t = i18n[currentLang];
  const name = prompt(t.promptName);
  if (!name) return;
  let url = prompt(t.promptUrl);
  if (!url) return;
  if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
  getCurrentPage().categories[catIdx].links.push({ name, url });
  save(); render();
}

function deleteCategory(idx) {
  getCurrentPage().categories.splice(idx, 1);
  save(); render();
}

function deleteLink(c, l) {
  getCurrentPage().categories[c].links.splice(l, 1);
  save(); render();
}

function addCategory() {
  const name = prompt(i18n[currentLang].promptCat);
  if (!name) return;
  getCurrentPage().categories.push({ id: name, links: [] });
  save(); render();
}

function save() {
  chrome.storage.local.set({ pages, currentPage });
}


chkEdit.addEventListener('change', () => {
  isEditing = chkEdit.checked;
  render();
});

themeSelect.addEventListener('change', () => {
  applyTheme();
  render();
});

langSelect.addEventListener('change', e => {
  currentLang = e.target.value;
  chrome.storage.local.set({ lang: currentLang });
  render();
});

btnAddCat.addEventListener('click', addCategory);


btnCustomize.addEventListener('click', () => {
  cpBg.value         = customColors.bg;
  cpSurface.value    = customColors.surface;
  cpHeader.value     = customColors.header;
  cpHeaderText.value = customColors.headerText;
  cpText.value       = customColors.text;
  cpAccent.value     = customColors.accent;
  cpRadius.value     = customColors.radius;
  cpRadiusVal.textContent = customColors.radius + 'px';
  customPanel.classList.toggle('hidden');
});

cpRadius.addEventListener('input', () => {
  cpRadiusVal.textContent = cpRadius.value + 'px';
});

[cpBg, cpSurface, cpHeader, cpHeaderText, cpText, cpAccent, cpRadius].forEach(el => {
  el.addEventListener('input', () => {
    customColors = {
      bg:         cpBg.value,
      surface:    cpSurface.value,
      header:     cpHeader.value,
      headerText: cpHeaderText.value,
      text:       cpText.value,
      accent:     cpAccent.value,
      radius:     Number(cpRadius.value),
    };
    themeSelect.value = 'custom';
    document.documentElement.setAttribute('data-theme', 'custom');
    applyCustomColors();
  });
});

btnSaveCust.addEventListener('click', () => {
  customColors = {
    bg:         cpBg.value,
    surface:    cpSurface.value,
    header:     cpHeader.value,
    headerText: cpHeaderText.value,
    text:       cpText.value,
    accent:     cpAccent.value,
    radius:     Number(cpRadius.value),
  };
  themeSelect.value = 'custom';
  applyCustomColors();
  chrome.storage.local.set({ customColors, theme: 'custom' });
  customPanel.classList.add('hidden');
});


document.getElementById('btnExport').addEventListener('click', () => {
  const data = { pages, currentPage };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'links-hub-backup.json';
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('btnImport').addEventListener('click', () => {
  document.getElementById('fileImport').click();
});

document.getElementById('fileImport').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const imported = JSON.parse(ev.target.result);

      
      if (Array.isArray(imported)) {
        pages = [{ id: 'page_default', name: 'Імпорт', categories: imported }];
        currentPage = 'page_default';
      } else if (imported.pages) {
        pages       = imported.pages;
        currentPage = imported.currentPage || pages[0].id;
      } else {
        throw new Error();
      }

      save();
      renderPageSelect();
      render();
    } catch {
      alert('Помилка: невірний формат файлу');
    }
  };
  reader.readAsText(file);
  e.target.value = '';
});
